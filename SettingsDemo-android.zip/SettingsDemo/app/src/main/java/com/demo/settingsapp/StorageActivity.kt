package com.demo.settingsapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class StorageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_storage)
        findViewById<android.widget.ImageView>(R.id.backArrow).setOnClickListener { finish() }
    }
}
