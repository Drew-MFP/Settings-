package com.demo.settingsapp

import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BatteryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_battery)

        findViewById<android.widget.ImageView>(R.id.backArrow).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        updateBattery()
    }

    private fun updateBattery() {
        val batteryStatus = registerReceiver(null, IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 90

        val remaining = when {
            charging -> "Charging"
            pct > 80 -> "More than 2 days remaining"
            pct > 50 -> "About 1 day remaining"
            pct > 20 -> "A few hours remaining"
            else -> "Less than 1 hour remaining"
        }

        findViewById<TextView>(R.id.batteryPercentText).text = pct.toString()
        findViewById<TextView>(R.id.batteryRemainingText).text = remaining

        // Fill the battery graphic proportionally: teal rises from the bottom
        // based on the real percentage, white occupies the remaining top portion.
        val containerHeightDp = 92f
        val density = resources.displayMetrics.density
        val containerHeightPx = (containerHeightDp * density)
        val fillHeightPx = (containerHeightPx * (pct / 100f)).toInt().coerceIn(0, containerHeightPx.toInt())

        val fillView = findViewById<android.view.View>(R.id.batteryTealFill)
        val params = fillView.layoutParams as FrameLayout.LayoutParams
        params.height = fillHeightPx
        fillView.layoutParams = params
    }
}
