package com.demo.settingsapp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Draws a simple circular progress ring (gray track + teal arc),
 * matching the Storage screen's "19% used" indicator.
 */
class ArcProgressView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var progressPercent: Float = 19f
        set(value) {
            field = value
            invalidate()
        }

    private val strokeWidthPx = 3 * resources.displayMetrics.density
    private val rect = RectF()

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokeWidthPx
        color = Color.parseColor("#E0E0E0")
    }

    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = strokeWidthPx
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#00897B")
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val inset = strokeWidthPx / 2f
        rect.set(inset, inset, width - inset, height - inset)

        canvas.drawOval(rect, trackPaint)

        val sweep = 360f * (progressPercent / 100f)
        canvas.drawArc(rect, -90f, sweep, false, progressPaint)
    }
}
