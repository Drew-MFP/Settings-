package com.demo.settingsapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DisplayActivity : AppCompatActivity() {

    private lateinit var seek: SeekBar
    private lateinit var valueText: TextView
    private lateinit var hintText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display)
        findViewById<ImageView>(R.id.backArrow).setOnClickListener { finish() }

        seek = findViewById(R.id.brightnessSeek)
        valueText = findViewById(R.id.brightnessValue)
        hintText = findViewById(R.id.brightnessHint)

        hintText.setOnClickListener { requestWritePermission() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                // Slider covers 1..255 (progress 0..254). 0 would turn some screens fully black.
                val level = progress + 1
                valueText.text = "${toPercent(level)}%"
                if (!fromUser) return
                if (!Settings.System.canWrite(this@DisplayActivity)) {
                    requestWritePermission()
                    syncFromSystem()
                    return
                }
                applyBrightness(level)
            }

            override fun onStartTrackingTouch(bar: SeekBar) {}
            override fun onStopTrackingTouch(bar: SeekBar) {}
        })
    }

    override fun onResume() {
        super.onResume()
        // Re-check after returning from the permission screen or if brightness changed elsewhere.
        hintText.visibility =
            if (Settings.System.canWrite(this)) android.view.View.GONE else android.view.View.VISIBLE
        syncFromSystem()
    }

    private fun syncFromSystem() {
        val level = try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Settings.SettingNotFoundException) {
            128
        }.coerceIn(1, 255)
        seek.progress = level - 1
        valueText.text = "${toPercent(level)}%"
    }

    private fun applyBrightness(level: Int) {
        // Manual mode so auto-brightness doesn't override the slider.
        Settings.System.putInt(
            contentResolver,
            Settings.System.SCREEN_BRIGHTNESS_MODE,
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        )
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, level)
    }

    private fun requestWritePermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_WRITE_SETTINGS,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun toPercent(level: Int): Int = Math.round(level * 100f / 255f)
}
