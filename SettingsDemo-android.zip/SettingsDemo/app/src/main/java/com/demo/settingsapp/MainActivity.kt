package com.demo.settingsapp

import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.widget.LinearLayout>(R.id.rowBattery).setOnClickListener {
            startActivity(Intent(this, BatteryActivity::class.java))
        }
        findViewById<android.widget.LinearLayout>(R.id.rowDisplay).setOnClickListener {
            startActivity(Intent(this, DisplayActivity::class.java))
        }
        findViewById<android.widget.LinearLayout>(R.id.rowSound).setOnClickListener {
            startActivity(Intent(this, SoundActivity::class.java))
        }
        findViewById<android.widget.LinearLayout>(R.id.rowStorage).setOnClickListener {
            startActivity(Intent(this, StorageActivity::class.java))
        }
        findViewById<android.widget.LinearLayout>(R.id.rowAccessibility).setOnClickListener {
            startActivity(Intent(this, AccessibilityActivity::class.java))
        }
        findViewById<android.widget.LinearLayout>(R.id.rowSystem).setOnClickListener {
            startActivity(Intent(this, SystemActivity::class.java))
        }
        findViewById<android.widget.LinearLayout>(R.id.rowAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateBatterySubtitle()
    }

    private fun updateBatterySubtitle() {
        val batteryStatus = registerReceiver(null, IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL

        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else 90

        val remaining = when {
            charging -> "Charging"
            pct > 80 -> "More than 2 days remaining"
            pct > 50 -> "About 1 day remaining"
            pct > 20 -> "A few hours remaining"
            else -> "Less than 1 hour remaining"
        }

        findViewById<TextView>(R.id.batterySubtitle).text = "$pct% - $remaining"
    }
}
