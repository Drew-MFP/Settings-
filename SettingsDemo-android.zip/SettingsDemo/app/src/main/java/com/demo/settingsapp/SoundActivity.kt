package com.demo.settingsapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class SoundActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sound)
        findViewById<android.widget.ImageView>(R.id.backArrow).setOnClickListener { finish() }
    }
}
